#9.4 심사문제: 여러 줄로 된 문자열 사용하기
s = """
'Python' is a "programming language"
that lets you work quickly
and
integrate systems more effectively."""
print(s)