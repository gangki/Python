#10.5 심사문제: range로 튜플 만들기
n = int(input())
a = tuple(range(-10, 10, n))
print(a)