# 12.5 심사문제: 딕셔너리에 게임 캐릭터 능력치 저장하기
key = input().split()
value = input().split()
lux = dict(zip(key, value))
print(lux)