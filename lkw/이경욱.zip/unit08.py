# 8.5 심사문제: 합격 여부 출력하기
a, b, c, d = input().split()
a = int(a)
b = int(b)
c = int(c)
d = int(d)
a >= 90 and b > 80 and c > 85 and d >=80